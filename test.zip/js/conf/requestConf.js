define('requestConf', [], function() {

    var RequestConf = {
        "token": "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2MTI4Nzc3ODEsImlkIjoib25ldXAtaW50ZXJ2aWV3Iiwib3JpZ19pYXQiOjE2MTIyNzI5ODEsInVzZXJpZCI6MjI3OTkwNywidXNlcm5hbWUiOiJvbmV1cC1pbnRlcnZpZXcifQ.xvkP8QSHp5ywBUbaTZ3bpT2sRUDqYg5eQZQOLGZCcasbdW3zRmVKx7wYg1uYSF2_ztQoSEMqCWYZLkWgpGJhs_PiaeXErye8EJVcf73o2QczmJz_gtj12NBh6KjHmyoFPY-dMNh3igU-EZAs5X-IZbTcx78nWM40HxJOgxEW5jjsMAi5HqzybENJMgBV9OJOCYNgMXnOCVhAohSTLrw6SdCUtLuKhQxCPpJZ_su6UL14S9jr3rsmzbq6Yf8chgBiFSpsgBvnr3O3wNrklK7qU6xYA0oWyZfM8g_jS0LGRyWkXsToJZtwqstFlj2QXtm9quOgQqP4P8paVY_m_LTSaA"

    };

    return RequestConf;

});
