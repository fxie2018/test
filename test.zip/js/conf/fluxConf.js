define('fluxConf', [], function() {

    var FluxConf = {
        show_url:": https://api.thetvdb.com/search/series?name="
    };

    return FluxConf;

});
